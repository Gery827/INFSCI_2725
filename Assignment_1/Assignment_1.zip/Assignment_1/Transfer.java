
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberInputStream;

import javax.swing.text.html.HTMLDocument.HTMLReader.SpecialAction;


public class Transfer {
    //transform Ratings.dat to Ratings.json
	public static void transferRatings(File srcFile, File destFile) throws IOException {
        //get the data from Ratings.dat
		BufferedReader br = new BufferedReader(new FileReader(srcFile));
        //use to storage data after treatment
		BufferedWriter bw = new BufferedWriter(new FileWriter(destFile));
        //define the head name
		final String[] names = { "UserID", "MovieID", "Rating", "Timestamp" };
		String line = null;
        //begin to read the Ratings.dat line by line
		while ((line = br.readLine()) != null) {
            //replace " to ' in every tuple
			String newLine = line.replace("\"", "'");
            //Use :: as separator
			String[] elements = newLine.split("::");
            //put the data into Ratings.json line by line
			bw.write("{");
			for (int i = 0; i < names.length; i++) {
				if (i == 2) {// i==2-->Rating
					bw.write("\"" + names[i] + "\":" + elements[i] + ",");
				} else if (i == names.length - 1) {
					bw.write("\"" + names[i] + "\":\"" + elements[i] + "\"");
				} else {
					bw.write("\"" + names[i] + "\":\"" + elements[i] + "\",");
				}
			}
			bw.write("}");
			bw.newLine();
			bw.flush();
		}
		bw.close();
		br.close();
		System.out.println("transfer the file Ratings successfully!");
	}
    //transform tags.dat to tags.json
	
	public static void transfertags(File srcFile, File destFile) throws IOException {
        //get the data from tags.dat
		BufferedReader br = new BufferedReader(new FileReader(srcFile));
        //use to storage data after treatment
		BufferedWriter bw = new BufferedWriter(new FileWriter(destFile));
		// UserID::MovieID::Tag::Timestamp
		final String[] names = { "UserID", "MovieID", "Tag", "Timestamp" };
		String line = null;
        //begin to read the tags.dat line by line
		while ((line = br.readLine()) != null) {
            //replace " to ' in every tuple
			String newLine = line.replace("\"", "'");
            //Use :: as a separator
			String[] elements = newLine.split("::");
			bw.write("{");
            //put the data into tags.json line by line
			for (int i = 0; i < names.length; i++) {
				if (i == names.length - 1) {
					bw.write("\"" + names[i] + "\":\"" + elements[i] + "\"");
				} else {
					bw.write("\"" + names[i] + "\":\"" + elements[i] + "\",");
				}
			}
			bw.write("}");
			bw.newLine();
			bw.flush();
		}
		bw.close();
		br.close();
		System.out.println("transfer the file Tags successfully!");
	}
    //transform Movies.dat to Movies.json
	
	public static void transferMovies(File srcFile, File destFile) throws IOException {
        //get the data from Movies.dat
		BufferedReader br = new BufferedReader(new FileReader(srcFile));
        //use to storage data after treatment
		BufferedWriter bw = new BufferedWriter(new FileWriter(destFile));
		// MovieID::Title::Genres
		final String[] names = { "MovieID", "Title", "Genres" };
		String line = null;
        //begin to read the Movies.dat line by line
		while ((line = br.readLine()) != null) {
            //replace " to ' in every tuple
			String newLine = line.replace("\"", "'");
            //Use :: as separator
			String[] elements = newLine.split("::");
			bw.write("{");
			for (int i = 0; i < 2; i++) {// the first two elements
				bw.write("\"" + names[i] + "\":\"" + elements[i] + "\",");
			}
			bw.write("\"" + names[2] + "\":[");
			// the second elements, need to be array elements[2]
			String[] subElemnets = elements[2].replace("|", ",").split(",");
            //put the data into Movies.json line by line
			for (int i = 0; i < subElemnets.length; i++) {
				if (i == subElemnets.length - 1) {
					bw.write("\"" + subElemnets[i] + "\"");
				} else {
					bw.write("\"" + subElemnets[i] + "\",");
				}
			}
			bw.write("]");
			bw.write("}");
			bw.newLine();
			bw.flush();
		}
		bw.close();
		br.close();
		System.out.println("transfer the file Movies successfully!");
	}

}
