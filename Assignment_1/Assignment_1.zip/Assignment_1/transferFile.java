import java.io.File;
import java.io.IOException;

public class transferFile {
	public  static void main(String[] args){
		
		File f1 = new File("/Users/Yifan/Documents/workspace/Data_Analytics/src/movies.dat");
		File f2 = new File("movies.json");
		try {
			Transfer.transferMovies(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		File f3 = new File("/Users/Yifan/Documents/workspace/Data_Analytics/src/ratings.dat");
		File f4 = new File("ratings.json");
		try {
			Transfer.transferRatings(f3, f4);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		File f5 = new File("/Users/Yifan/Documents/workspace/Data_Analytics/src/tags.dat");
		File f6 = new File("tags.json");
		try {
			Transfer.transfertags(f5, f6);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
